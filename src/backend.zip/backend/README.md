# Contenedor de la aplicación Python/Flask

Iniciar servicio desde la raiz del proyecto 

```bash
   docker-compose build
   docker-compose up
```

Salida esperada de inicio de aplicación

```bash
  * Serving Flask app 'app'
  misw-desarrollonube-backend  |  * Debug mode: on
  misw-desarrollonube-backend  |  WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
  misw-desarrollonube-backend  |  * Running on all addresses (0.0.0.0)
  misw-desarrollonube-backend  |  * Running on http://127.0.0.1:8000
```