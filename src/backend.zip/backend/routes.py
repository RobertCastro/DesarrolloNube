from backend import app
from flask import Blueprint
from .controllers.auth_controller import login, register
from .controllers.video_controller import upload_video

main = Blueprint('main', __name__)

@app.route('/')
def root():
    return '¡Flask app running in a Docker container! 🐳🐍🚀R'
  
main.route('/login', methods=['POST'])(login)
main.route('/register', methods=['POST'])(register)
main.route('/video', methods=['POST'])(upload_video)
